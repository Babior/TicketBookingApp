# list screenings after selected day nad time
curl localhost:8080/screenings/after/2020-04-10T15:49:01.549
# choose one of the screenings
curl localhost:8080/screenings/8



